import "../../../Anzas.Manacy.Web/Scripts/Enums";
import "../../../Anzas.Manacy.Web/Scripts/TypeLite.Net4.d";
import "./global";
import "./namespaces";

import Models = Anzas.Manacy.Models;

export default Models;
