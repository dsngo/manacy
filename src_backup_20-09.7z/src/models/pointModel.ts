export class PointModel {
  constructor(public x: number = 1, public y: number = 1) {}
}
