import "../../../Anzas.Manacy.Web/Scripts/Enums";
import "../../../Anzas.Manacy.Web/Scripts/TypeLite.Net4";
import "./global";
import "./namespaces";

import Logic = Anzas.Manacy.Logic;

export default Logic;
